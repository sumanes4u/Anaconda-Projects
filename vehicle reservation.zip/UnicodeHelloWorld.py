# This program displays the Unicode encoding for 'Hello World!

# Program Greeting
print ("The Unicode encoding for 'Hello World! is:")

# Output Results
print (ord('H'), ord('e'), ord('l'), ord('l'), ord('o'),
       ord(' '), ord('w'), ord('o'), ord('r'), ord('l'), ord('d'), ord('!'))
