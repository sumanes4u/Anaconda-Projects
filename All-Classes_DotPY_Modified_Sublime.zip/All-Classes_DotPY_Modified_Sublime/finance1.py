'''
This is sample function
'''

def addTax(price,tax):
    newPrice = price/100
    return newPrice